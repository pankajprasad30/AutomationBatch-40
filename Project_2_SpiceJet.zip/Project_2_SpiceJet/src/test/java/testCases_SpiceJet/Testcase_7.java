package testCases_SpiceJet;

import org.testng.annotations.Test;

public class Testcase_7 extends Launch_Quit
{
	//test for multicity flight search : In spice jet multi city option is not there.
	@Test
	public void MultiCity_Search()
	{
		
	}

}
